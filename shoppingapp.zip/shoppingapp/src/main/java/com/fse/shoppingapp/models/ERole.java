package com.fse.shoppingapp.models;

public enum ERole {
    ROLE_USER,
    ROLE_GUEST,
    ROLE_ADMIN
}
